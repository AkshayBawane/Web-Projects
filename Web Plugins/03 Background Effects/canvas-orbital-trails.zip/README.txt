A Pen created at CodePen.io. You can find this one at http://codepen.io/jackrugile/pen/DGenc.

 Click and drag anywhere on the screen to create new trails. Also, be sure to check v2: http://codepen.io/jackrugile/pen/aCzHs