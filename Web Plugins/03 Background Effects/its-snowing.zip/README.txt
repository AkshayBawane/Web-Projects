A Pen created at CodePen.io. You can find this one at http://codepen.io/loktar00/pen/CHpGo.

 Super simple snow I threw together for an answer on stack overflow. Added some simple mouse interaction to make flakes move away from the cursor.