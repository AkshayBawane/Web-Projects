A Pen created at CodePen.io. You can find this one at http://codepen.io/akm2/pen/Aatbf.

 http://jsdo.it/akm2/pQbM

Lightning Points (Lightning 2)
http://codepen.io/akm2/pen/LuDba