A Pen created at CodePen.io. You can find this one at http://codepen.io/giana/pen/RPdLaQ.

 Firefox (& Webkit)-compatible gradient text using CSS blend modes. Looking for ways to simplify.

Edit: As of November 2015, this is broken in the latest versions of Chrome. Was working before and will be fixed in some future version.

Edit 2: This is working in Chrome again.

The Webkit-only way:  
https://css-tricks.com/snippets/css/gradient-text/

The SVG way:  
http://lea.verou.me/2012/05/text-masking-the-standards-way/