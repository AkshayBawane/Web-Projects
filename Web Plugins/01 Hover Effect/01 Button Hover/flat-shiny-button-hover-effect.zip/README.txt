A Pen created at CodePen.io. You can find this one at http://codepen.io/nw/pen/GqBzJ.

 Button with a subtle gloss/shine wipe on hover.
No images, just a single HTML element and a CSS pseudo-element.
Inspired by http://codepen.io/indyplanets/pen/LejJd