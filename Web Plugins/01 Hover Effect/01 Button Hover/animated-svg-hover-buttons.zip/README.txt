A Pen created at CodePen.io. You can find this one at http://codepen.io/Gingernaut/pen/qOgMLy.

 A lot of people liked the buttons I made for my website so I threw together a CodePen and added comments. This is pure HTML/CSS implementation of some SVG buttons with a cool hover effect. The colors and shapes can be customized to fit your needs.