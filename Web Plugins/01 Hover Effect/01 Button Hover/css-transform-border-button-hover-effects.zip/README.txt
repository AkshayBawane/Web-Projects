A Pen created at CodePen.io. You can find this one at http://codepen.io/lesbaa/pen/dojGVL.

 Use of transform on before and after pseudo elements to create border effects on hover. no js.