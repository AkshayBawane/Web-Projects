A Pen created at CodePen.io. You can find this one at http://codepen.io/davidicus/pen/emgQKJ.

 A few examples of flashy hover effects.Work in Progress