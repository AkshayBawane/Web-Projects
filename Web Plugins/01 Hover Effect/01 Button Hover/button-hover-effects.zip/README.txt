A Pen created at CodePen.io. You can find this one at http://codepen.io/kjbrum/pen/wBBLXx.

 Some button hover effects using psuedo elements and borders.