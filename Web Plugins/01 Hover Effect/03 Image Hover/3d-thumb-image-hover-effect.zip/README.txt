A Pen created at CodePen.io. You can find this one at http://codepen.io/pirrera/pen/tKFhI.

 3D CSS3 Hover Effect with Pseudo Element Shadow Effect