// Picture from Happy D
// http://drbl.in/kLRD