A Pen created at CodePen.io. You can find this one at http://codepen.io/honglio/pen/FKyxG.

 Inspired by tympanus.net, a showcase of most CSS3 hover effects.