A Pen created at CodePen.io. You can find this one at http://codepen.io/caraujo/pen/VYOjNM.

 A small collection of stylish effects with Less.
See also:  10 hover effcts with scss: http://codepen.io/caraujo/pen/LVPzxO