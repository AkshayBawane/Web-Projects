//WOW, 1K loves!
//check it too:  10 hover effects with scss
//http://codepen.io/caraujo/pen/LVPzxO