A Pen created at CodePen.io. You can find this one at http://codepen.io/magnificode/pen/zGVyQm.

 Simple multi layer box shadow hover effect.