A Pen created at CodePen.io. You can find this one at http://codepen.io/palimadra/pen/fFBDz.

 Gradient effect on hovering over a link