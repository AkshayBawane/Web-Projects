A Pen created at CodePen.io. You can find this one at http://codepen.io/vineethtr/pen/EaGbxW.

 Social sprite button's with different look and style on CSS3  