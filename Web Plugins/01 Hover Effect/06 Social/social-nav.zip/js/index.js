$(window).scroll(function(){
 var navTop =  $(window).scrollTop();
 $('.model-0').css("top", navTop + 50);
});







alsolike(
  "GJpxoQ", "Simple Spinners",
  "XJyqQr", "Loading",
  "VYRzaV", "open close"
);