A Pen created at CodePen.io. You can find this one at http://codepen.io/Kseso/pen/xqNdmO.

 sizes & lengths with only 1 CSS custom properties (in progress).  
TODO: shape-outside for texts & vertical centered

Another version: Auto Honeycomb CSS Grid Layout  
http://codepen.io/Kseso/full/zwKzQN/