require('./dist/angular-dashboard-framework');
module.exports = 'adf';
