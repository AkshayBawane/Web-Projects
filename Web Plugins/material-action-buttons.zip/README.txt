A Pen created at CodePen.io. You can find this one at http://codepen.io/vineethtr/pen/ZbapVR.

 Material Action button Collections with different transitions  