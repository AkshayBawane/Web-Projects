$('.btn-triger').click(function(){
  $(this).closest('.float-btn-group').toggleClass('open');
});