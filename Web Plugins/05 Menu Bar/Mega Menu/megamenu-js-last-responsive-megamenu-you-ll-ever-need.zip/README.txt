A Pen created at CodePen.io. You can find this one at http://codepen.io/riogrande/pen/MKXweV.

 Responsive, cross-browser,  jquery megamenu. Smart enough to know when to show megamenu and when not. Seamless wordpress integration.  Written in Less.