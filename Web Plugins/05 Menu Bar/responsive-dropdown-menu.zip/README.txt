A Pen created at CodePen.io. You can find this one at http://codepen.io/massiebn/pen/KrJvi.

 Responsive dropdown menu. http://osvaldas.info/drop-down-navigation-responsive-and-touch-friendly/