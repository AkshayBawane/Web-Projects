A Pen created at CodePen.io. You can find this one at http://codepen.io/chorijan/pen/aqDpo.

 like @csswizardry already made extended with responsive-nav.js plugin