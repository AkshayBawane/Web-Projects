/*
bootstrap like responsive navigation (no js)

basically using checkbox to trigger the pop down navigation. 
*/