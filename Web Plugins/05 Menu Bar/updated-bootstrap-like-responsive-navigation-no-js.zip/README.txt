A Pen created at CodePen.io. You can find this one at http://codepen.io/ImBobby/pen/mxqKL.

 I'm trying to make responsive navigation without javascript. I use checkbox to trigger the pop down navigation. 