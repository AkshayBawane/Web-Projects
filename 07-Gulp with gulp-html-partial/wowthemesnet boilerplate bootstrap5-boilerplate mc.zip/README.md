
# Bootstrap 5 Boilerplate - Basic

This is a Bootstrap 5 Boilerplate with Gulp 4+, cross-env, Sass, sourcemaps, concat, CSS & HTML minification, uglify, image optimization, template partials, BrowserSync.

[More in documentation](https://bootstrapstarter.com/template-basic5-bootstrap5-html/)

![bootstrapstarter](src/img/screenshot.png)

