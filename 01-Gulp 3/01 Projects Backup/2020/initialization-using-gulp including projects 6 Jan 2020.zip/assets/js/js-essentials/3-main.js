/*--------------------------------------------------
# main.js file for Launcher template.
# Author: Galacticlab
--------------------------------------------------*/

$(function($) {

    // For Scroll to top
    $(window).on("scroll resize", function() {
        if ($(window).scrollTop() >= 200) {
            $(".scroll-top").css("bottom", "15px");
        }
        if ($(window).scrollTop() < 200) {
            $(".scroll-top").css("bottom", "-52px");
        }
    });
    $(".scroll-top").on("click", function() {
        return $("html, body").animate({
            scrollTop: 0
        });
    });
    // END For Scroll to top
});