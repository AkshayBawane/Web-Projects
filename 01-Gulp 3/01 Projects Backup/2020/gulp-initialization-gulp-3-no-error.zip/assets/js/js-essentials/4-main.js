/*--------------------------------------------------
# main.js file
--------------------------------------------------*/
$(function($) {
    $(".toggle-btn").click(function () {
		$("body").toggleClass("toggle-btn-body");
		$(".banner-wrapper").toggleClass("animate-nav");
	});

	$(".down").click(function() {
		$('html, body').animate({
			scrollTop: $(".up").offset().top
		}, 1500);
	});
});