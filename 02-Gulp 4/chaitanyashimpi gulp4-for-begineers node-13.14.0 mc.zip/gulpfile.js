const gulp          = require('gulp');
const sass          = require('gulp-sass');
const browserSync   = require('browser-sync').create();
const useref        = require('gulp-useref');
const uglify        = require('gulp-uglify');
const gulpIf        = require('gulp-if');
const cssnano       = require('gulp-cssnano');
const imagemin      = require('gulp-imagemin');
const cache         = require('gulp-cache');
const del           = require('del');
const runSequence   = require('gulp4-run-sequence');

// Main Gulp Task

// Compile sass into CSS and auto inject into browsers
gulp.task('sass', function(){
	return gulp.src("assets/scss/**/*.+(sass|scss)")
		.pipe(sass())
		.pipe(gulp.dest("assets/css"))
		.pipe(browserSync.stream());
});

// Statis Server + watching scss/html/js files
gulp.task('server', gulp.series('sass', function(){
	browserSync.init({
		server: "./assets/"
	});
	gulp.watch("assets/scss/**/*.+(sass|scss)", gulp.series('sass'));
	gulp.watch("assets/js/**/*.js").on('change', browserSync.reload);
	gulp.watch("assets/**/*.html").on('change', browserSync.reload);
}));

gulp.task('default', gulp.series('server'));

// Optimization Tasks

// Minifying the Js files
gulp.task('useref', function(){
	return gulp.src('assets/*.html')
	.pipe(useref())
	// Minifies only if its a Javascript file
	.pipe(gulpIf('*.js',uglify()))
	.pipe(gulp.dest('build'))
});

// Minifying the CSS files
gulp.task ('useref', function(){
	return gulp.src('assets/*.html')
	.pipe(useref())
	// Minify only if its a CSS file
	.pipe(gulpIf('*.css', cssnano()))
	.pipe(gulp.dest('build'))
});

// Optimizing the Images
gulp.task('images', function(){
	return gulp.src('assets/images/**/*.+(png|jpg|gif|svg)')
	.pipe(cache(imagemin({
		interlaced: true
	})))
	.pipe(gulp.dest('build/images'))
});

// Copying the fonts in build
gulp.task('fonts', function() {
	return gulp.src('assets/fonts/**/*')
	.pipe(gulp.dest('build/fonts'))
})

// // Cleaning
// gulp.task('clean', function() {
//     return del.sync('build').then(function(cb) {
//         return cache.clearAll(cb);
//     });
// })

// gulp.task('clean:build', function() {
//     return del.sync(['build/**/*', '!build/images', '!build/images/**/*']);
// });

// Build Sequences
// ---------------

gulp.task('build', function(callback) {
	runSequence(
		// 'clean:build',
		'sass',['useref', 'images', 'fonts'],
		callback
	)
})
