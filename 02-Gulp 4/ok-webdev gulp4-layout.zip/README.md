# Gulp4 for layout without build mode

## Inside:
- browser-sync
- gulp-concat
- gulp-uglify-es
- gulp-htmlmin
- gulp-sass
- gulp-autoprefixer
- gulp-clean-css
- gulp-imagemin
- gulp-babel
- del
- newer

````bash
nmp i - install dependencies
````
````bash
gulp - default dev mode
````
````bash
gulp cleandist - delete dist folder
````